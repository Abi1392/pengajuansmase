import 'dart:typed_data';

import 'package:flutter/material.dart';

class FullscreenImage extends StatelessWidget {
  final Uint8List bytes;
  final String? title;

  const FullscreenImage({
    super.key,
    required this.bytes,
    this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(title ?? 'Foto'),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 0.5,
          maxScale: 5.0,
          panEnabled: true,
          scaleEnabled: true,
          child: Image.memory(
            bytes,
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) {
              return const Center(
                child: Text(
                  'Foto tidak dapat ditampilkan',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

void bukaFotoFullscreen(
  BuildContext context, {
  required Uint8List bytes,
  String? title,
}) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => FullscreenImage(
        bytes: bytes,
        title: title,
      ),
    ),
  );
}
