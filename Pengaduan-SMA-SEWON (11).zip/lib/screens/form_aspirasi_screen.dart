import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models/aspirasi.dart';
import '../models/kategori.dart';
import '../services/firestore_service.dart';

class FormAspirasiScreen extends StatefulWidget {
  final String nis;
  final String kelas;
  final String nama;

  const FormAspirasiScreen({
    super.key,
    required this.nis,
    required this.kelas,
    required this.nama,
  });

  @override
  State<FormAspirasiScreen> createState() => _FormAspirasiScreenState();
}

class _FormAspirasiScreenState extends State<FormAspirasiScreen> {
  final _formKey = GlobalKey<FormState>();

  final _lokasiController = TextEditingController();

  final _keteranganController = TextEditingController();

  final FirestoreService _service = FirestoreService();

  final ImagePicker _picker = ImagePicker();

  String _idKategoriTerpilih = KategoriData.daftarKategori.first.idKategori;

  bool _sedangMenyimpan = false;

  Uint8List? _fotoBytes;
  String _fotoBase64 = '';

  @override
  void dispose() {
    _lokasiController.dispose();
    _keteranganController.dispose();
    super.dispose();
  }

  // ============================================================
  // PILIH FOTO
  // ============================================================

  Future<void> _pilihFoto(ImageSource source) async {
    try {
      final XFile? file = await _picker.pickImage(
        source: source,
        imageQuality: 40,
        maxWidth: 800,
      );

      if (file == null) return;

      final bytes = await file.readAsBytes();

      if (!mounted) return;

      setState(() {
        _fotoBytes = bytes;
        _fotoBase64 = base64Encode(bytes);
      });
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Gagal mengambil foto: $e',
          ),
        ),
      );
    }
  }

  // ============================================================
  // HAPUS FOTO
  // ============================================================

  void _hapusFoto() {
    setState(() {
      _fotoBytes = null;
      _fotoBase64 = '';
    });
  }

  // ============================================================
  // PILIH SUMBER FOTO
  // ============================================================

  void _tampilkanPilihanSumberFoto() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text('Ambil dari Kamera'),
                onTap: () {
                  Navigator.pop(context);
                  _pilihFoto(
                    ImageSource.camera,
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Pilih dari Galeri'),
                onTap: () {
                  Navigator.pop(context);
                  _pilihFoto(
                    ImageSource.gallery,
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  // ============================================================
  // RESET FORM
  // ============================================================

  void _resetForm() {
    _formKey.currentState?.reset();

    _lokasiController.clear();
    _keteranganController.clear();

    setState(() {
      _idKategoriTerpilih = KategoriData.daftarKategori.first.idKategori;

      _fotoBytes = null;
      _fotoBase64 = '';
    });
  }

  // ============================================================
  // SIMPAN ASPIRASI
  // ============================================================

  Future<void> _simpanAspirasi() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_sedangMenyimpan) {
      return;
    }

    setState(() {
      _sedangMenyimpan = true;
    });

    final aspirasiBaru = Aspirasi(
      nis: widget.nis,
      nama: widget.nama,
      kelas: widget.kelas,
      idKategori: _idKategoriTerpilih,
      kategori: KategoriData.cariKetKategori(
        _idKategoriTerpilih,
      ),
      lokasi: _lokasiController.text.trim(),
      keterangan: _keteranganController.text.trim(),
      status: 'Menunggu',
      feedback: '',
      fotoBase64: _fotoBase64,
    );

    try {
      await _service.tambahAspirasi(
        aspirasiBaru,
      );

      if (!mounted) return;

      // ========================================================
      // PENTING:
      // JANGAN Navigator.pop(context)
      //
      // Karena FormAspirasiScreen berada di IndexedStack.
      // ========================================================

      _resetForm();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Aspirasi berhasil dikirim!',
          ),
          backgroundColor: Colors.green,
          duration: Duration(seconds: 3),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Gagal mengirim aspirasi:\n$e',
          ),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 4),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _sedangMenyimpan = false;
        });
      }
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Form Aspirasi Siswa',
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // ==================================================
              // DATA SISWA
              // ==================================================

              Container(
                padding: const EdgeInsets.all(
                  16,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(
                    15,
                  ),
                  border: Border.all(
                    color: Colors.grey.shade200,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Data Siswa',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Nama: ${widget.nama}',
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'NIS: ${widget.nis}',
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Kelas: ${widget.kelas}',
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // ==================================================
              // KATEGORI
              // ==================================================

              DropdownButtonFormField<String>(
                value: _idKategoriTerpilih,
                decoration: const InputDecoration(
                  labelText: 'Kategori Pengaduan',
                  border: OutlineInputBorder(),
                ),
                items: KategoriData.daftarKategori
                    .map(
                      (k) => DropdownMenuItem(
                        value: k.idKategori,
                        child: Text(
                          k.ketKategori,
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value == null) {
                    return;
                  }

                  setState(() {
                    _idKategoriTerpilih = value;
                  });
                },
              ),

              const SizedBox(height: 12),

              // ==================================================
              // LOKASI
              // ==================================================

              TextFormField(
                controller: _lokasiController,
                maxLength: 50,
                decoration: const InputDecoration(
                  labelText: 'Lokasi',
                  hintText: 'Contoh: Ruang Kelas XII RPL 1',
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) {
                    return 'Lokasi wajib diisi';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 12),

              // ==================================================
              // KETERANGAN
              // ==================================================

              TextFormField(
                controller: _keteranganController,
                maxLength: 50,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Keterangan Pengaduan',
                  hintText: 'Jelaskan masalah/kerusakan secara singkat',
                  border: OutlineInputBorder(),
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) {
                    return 'Keterangan wajib diisi';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 16),

              // ==================================================
              // FOTO
              // ==================================================

              const Text(
                'Foto Bukti (Opsional)',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              if (_fotoBytes == null)
                OutlinedButton.icon(
                  icon: const Icon(
                    Icons.add_a_photo,
                  ),
                  label: const Text(
                    'Tambah Foto',
                  ),
                  onPressed: _tampilkanPilihanSumberFoto,
                )
              else
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(
                        8,
                      ),
                      child: Image.memory(
                        _fotoBytes!,
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        TextButton.icon(
                          icon: const Icon(
                            Icons.refresh,
                            size: 18,
                          ),
                          label: const Text(
                            'Ganti Foto',
                          ),
                          onPressed: _tampilkanPilihanSumberFoto,
                        ),
                        TextButton.icon(
                          icon: const Icon(
                            Icons.delete,
                            size: 18,
                            color: Colors.red,
                          ),
                          label: const Text(
                            'Hapus',
                            style: TextStyle(
                              color: Colors.red,
                            ),
                          ),
                          onPressed: _hapusFoto,
                        ),
                      ],
                    ),
                  ],
                ),

              const SizedBox(height: 24),

              // ==================================================
              // TOMBOL KIRIM
              // ==================================================

              SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  icon: _sedangMenyimpan
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(
                          Icons.send,
                        ),
                  label: Text(
                    _sedangMenyimpan ? 'Mengirim...' : 'Kirim Aspirasi',
                  ),
                  onPressed: _sedangMenyimpan ? null : _simpanAspirasi,
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
