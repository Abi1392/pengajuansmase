import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/aspirasi.dart';
import '../services/firestore_service.dart';
import '../widgets/fullscreen_image.dart';

class HistoriAspirasiScreen extends StatelessWidget {
  final String nis;

  const HistoriAspirasiScreen({
    super.key,
    required this.nis,
  });

  Color _warnaStatus(String status) {
    switch (status) {
      case 'Selesai':
        return Colors.green;

      case 'Proses':
        return Colors.orange;

      default:
        return Colors.redAccent;
    }
  }

  // ============================================================
  // DIALOG RATING
  // ============================================================

  Future<void> _bukaDialogRating(
    BuildContext context,
    Aspirasi item,
  ) async {
    if (item.id == null) {
      return;
    }

    int ratingDipilih = 0;

    final hasil = await showDialog<int>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text(
                'Beri Rating Pengaduan',
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Bagaimana penanganan '
                    'pengaduan Anda?',
                    textAlign: TextAlign.center,
                  ),

                  const SizedBox(
                    height: 20,
                  ),

                  // =================================================
                  // BINTANG
                  // =================================================

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      5,
                      (index) {
                        final nomor = index + 1;

                        return IconButton(
                          onPressed: () {
                            setState(() {
                              ratingDipilih = nomor;
                            });
                          },
                          icon: Icon(
                            nomor <= ratingDipilih
                                ? Icons.star
                                : Icons.star_border,
                            size: 40,
                            color: Colors.amber,
                          ),
                        );
                      },
                    ),
                  ),

                  const SizedBox(
                    height: 8,
                  ),

                  Text(
                    ratingDipilih == 0
                        ? 'Pilih rating'
                        : '$ratingDipilih dari 5 bintang',
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(
                      dialogContext,
                    );
                  },
                  child: const Text(
                    'Batal',
                  ),
                ),
                ElevatedButton(
                  onPressed: ratingDipilih == 0
                      ? null
                      : () {
                          Navigator.pop(
                            dialogContext,
                            ratingDipilih,
                          );
                        },
                  child: const Text(
                    'Kirim Rating',
                  ),
                ),
              ],
            );
          },
        );
      },
    );

    if (hasil == null) {
      return;
    }

    // ==========================================================
    // SIMPAN RATING
    // ==========================================================

    try {
      await FirestoreService().beriRating(
        idAspirasi: item.id!,
        rating: hasil,
      );

      if (!context.mounted) {
        return;
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(
        const SnackBar(
          content: Text(
            'Rating berhasil disimpan. Terima kasih!',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!context.mounted) {
        return;
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(
        SnackBar(
          content: Text(
            'Gagal menyimpan rating: $e',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  // ============================================================
  // TAMPILKAN RATING
  // ============================================================

  Widget _widgetRating(
    BuildContext context,
    Aspirasi item,
  ) {
    // ==========================================================
    // BELUM SELESAI → TIDAK ADA RATING
    // ==========================================================

    if (item.status != 'Selesai') {
      return const SizedBox.shrink();
    }

    // ==========================================================
    // SUDAH MEMBERI RATING
    // ==========================================================

    if (item.rating != null) {
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(
          top: 14,
        ),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.amber.withValues(
            alpha: 0.12,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.amber.withValues(
              alpha: 0.5,
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Rating Anda',
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 6,
            ),
            Row(
              children: [
                ...List.generate(
                  5,
                  (index) {
                    return Icon(
                      index < item.rating! ? Icons.star : Icons.star_border,
                      color: Colors.amber,
                      size: 26,
                    );
                  },
                ),
                const SizedBox(
                  width: 8,
                ),
                Text(
                  '${item.rating}/5',
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 4,
            ),
            const Text(
              'Terima kasih atas penilaian Anda.',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      );
    }

    // ==========================================================
    // BELUM MEMBERI RATING
    // ==========================================================

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.amber.withValues(
          alpha: 0.08,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.amber.withValues(
            alpha: 0.4,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Pengaduan ini sudah selesai.',
            style: TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          const Text(
            'Berikan rating untuk '
            'penanganan pengaduan ini.',
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                _bukaDialogRating(
                  context,
                  item,
                );
              },
              icon: const Icon(
                Icons.star,
                color: Colors.amber,
              ),
              label: const Text(
                'Beri Rating',
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    final FirestoreService service = FirestoreService();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Histori Aspirasi Saya',
        ),
      ),
      body: StreamBuilder<List<Aspirasi>>(
        stream: service.streamHistoriByNis(
          nis,
        ),
        builder: (
          context,
          snapshot,
        ) {
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(
                  24,
                ),
                child: Text(
                  'Terjadi kesalahan: '
                  '${snapshot.error}',
                ),
              ),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          final daftar = snapshot.data ?? [];

          if (daftar.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Belum ada aspirasi '
                  'yang dikirim.',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: daftar.length,
            itemBuilder: (context, index) {
              final item = daftar[index];

              return Card(
                margin: const EdgeInsets.symmetric(
                  vertical: 6,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(
                    14,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ==================================================
                      // JUDUL + STATUS
                      // ==================================================

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              item.kategori,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: _warnaStatus(
                                item.status,
                              ).withValues(
                                alpha: 0.15,
                              ),
                              borderRadius: BorderRadius.circular(
                                20,
                              ),
                              border: Border.all(
                                color: _warnaStatus(
                                  item.status,
                                ),
                              ),
                            ),
                            child: Text(
                              item.status,
                              style: TextStyle(
                                color: _warnaStatus(
                                  item.status,
                                ),
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(
                        height: 6,
                      ),

                      Text(
                        'Lokasi: ${item.lokasi}',
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      Text(
                        'Keterangan: ${item.keterangan}',
                      ),

                      // ==================================================
                      // FOTO PENGADUAN
                      // ==================================================

                      if (item.fotoBase64.isNotEmpty) ...[
                        const SizedBox(
                          height: 10,
                        ),
                        GestureDetector(
                          onTap: () {
                            bukaFotoFullscreen(
                              context,
                              bytes: base64Decode(item.fotoBase64),
                              title: 'Foto Pengaduan',
                            );
                          },
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.memory(
                              base64Decode(item.fotoBase64),
                              height: 160,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],

                      // ==================================================
                      // TANGGAL
                      // ==================================================

                      if (item.tanggal != null) ...[
                        const SizedBox(
                          height: 8,
                        ),
                        Text(
                          'Tanggal: ${DateFormat('dd MMM yyyy, HH:mm').format(item.tanggal!)}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],

                      // ==================================================
                      // FEEDBACK ADMIN
                      // ==================================================

                      if (item.feedback.isNotEmpty) ...[
                        const Divider(
                          height: 20,
                        ),
                        const Text(
                          'Umpan Balik Admin:',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(
                          height: 4,
                        ),
                        Text(
                          item.feedback,
                        ),
                      ],

                      // ==================================================
                      // RATING
                      // ==================================================

                      _widgetRating(
                        context,
                        item,
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
