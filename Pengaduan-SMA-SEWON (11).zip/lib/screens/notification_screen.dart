import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/notification_service.dart';
import '../main.dart';

class NotificationScreen extends StatelessWidget {
  final String? nis;
  final String penerima;

  const NotificationScreen({
    super.key,
    this.nis,
    required this.penerima,
  });

  @override
  Widget build(BuildContext context) {
    final service = NotificationService();

    Stream<QuerySnapshot<Map<String, dynamic>>> stream;

    if (penerima == 'siswa' && nis != null) {
      stream = service.streamNotifikasiSiswa(nis!);
    } else if (penerima == 'admin') {
      stream = service.streamNotifikasiAdmin();
    } else {
      stream = service.streamNotifikasiPetugas();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Notifikasi',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          if (penerima == 'siswa' && nis != null)
            IconButton(
              tooltip: 'Tandai semua sudah dibaca',
              icon: const Icon(Icons.done_all),
              onPressed: () async {
                await service.tandaiSemuaDibacaSiswa(nis!);

                if (!context.mounted) return;

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Semua notifikasi sudah dibaca',
                    ),
                  ),
                );
              },
            ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(25),
                child: Text(
                  'Gagal memuat notifikasi.\n\n'
                  '${snapshot.error}',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          final docs = snapshot.data?.docs ?? [];

          if (docs.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.notifications_none,
                      size: 80,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Belum ada notifikasi',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Notifikasi pengaduan akan muncul di sini.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final doc = docs[index];
              final data = doc.data();

              final String judul = data['judul']?.toString() ?? 'Notifikasi';

              final String pesan = data['pesan']?.toString() ?? '';

              final bool dibaca = data['dibaca'] == true;

              final Timestamp? timestamp = data['waktu'] as Timestamp?;

              final DateTime? waktu = timestamp?.toDate();

              return _NotificationCard(
                judul: judul,
                pesan: pesan,
                dibaca: dibaca,
                waktu: waktu,
                onTap: () async {
                  if (!dibaca) {
                    await service.tandaiDibaca(
                      doc.id,
                    );
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
}

// ============================================================
// CARD NOTIFIKASI
// ============================================================

class _NotificationCard extends StatelessWidget {
  final String judul;
  final String pesan;
  final bool dibaca;
  final DateTime? waktu;
  final VoidCallback onTap;

  const _NotificationCard({
    required this.judul,
    required this.pesan,
    required this.dibaca,
    required this.waktu,
    required this.onTap,
  });

  String _formatWaktu(DateTime? waktu) {
    if (waktu == null) {
      return 'Baru saja';
    }

    final sekarang = DateTime.now();
    final selisih = sekarang.difference(waktu);

    if (selisih.inSeconds < 60) {
      return 'Baru saja';
    }

    if (selisih.inMinutes < 60) {
      return '${selisih.inMinutes} menit yang lalu';
    }

    if (selisih.inHours < 24) {
      return '${selisih.inHours} jam yang lalu';
    }

    if (selisih.inDays < 7) {
      return '${selisih.inDays} hari yang lalu';
    }

    return '${waktu.day}/${waktu.month}/${waktu.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: dibaca ? Colors.white : AppColors.primary.withOpacity(0.08),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: dibaca
                      ? Colors.grey.shade100
                      : AppColors.primary.withOpacity(0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  dibaca
                      ? Icons.notifications_none
                      : Icons.notifications_active,
                  color: dibaca ? Colors.grey : AppColors.primary,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            judul,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight:
                                  dibaca ? FontWeight.w600 : FontWeight.bold,
                            ),
                          ),
                        ),
                        if (!dibaca)
                          Container(
                            width: 9,
                            height: 9,
                            decoration: const BoxDecoration(
                              color: AppColors.primary,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      pesan,
                      style: TextStyle(
                        color: Colors.grey.shade700,
                        fontSize: 13,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _formatWaktu(waktu),
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
