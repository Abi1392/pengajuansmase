import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../main.dart';
import '../models/aspirasi.dart';
import '../models/petugas.dart';
import '../services/firestore_service.dart';
import '../services/notification_service.dart';
import '../widgets/fullscreen_image.dart';
import 'landing_screen.dart';
import 'help_screen.dart';
import 'notification_screen.dart';

/// Dashboard Petugas — untuk menangani aspirasi/pengaduan sarana sekolah.
/// Dirancang mobile-first karena petugas mengakses lewat APK.
class PetugasDashboardScreen extends StatefulWidget {
  final Petugas petugas;

  const PetugasDashboardScreen({super.key, required this.petugas});

  @override
  State<PetugasDashboardScreen> createState() => _PetugasDashboardScreenState();
}

class _PetugasDashboardScreenState extends State<PetugasDashboardScreen> {
  final FirestoreService _service = FirestoreService();
  final _searchController = TextEditingController();

  String _filterStatus = 'Aktif'; // Aktif = Menunggu + Proses

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  // ============================================================
  // FILTER
  // ============================================================

  List<Aspirasi> _terapkanFilter(List<Aspirasi> daftar) {
    return daftar.where((a) {
      bool cocokStatus;

      switch (_filterStatus) {
        case 'Aktif':
          cocokStatus = a.status == 'Menunggu' || a.status == 'Proses';
          break;

        case 'Semua':
          cocokStatus = true;
          break;

        default:
          cocokStatus = a.status == _filterStatus;
      }

      final kataKunci = _searchController.text.trim().toLowerCase();
      final cocokPencarian = kataKunci.isEmpty ||
          a.nama.toLowerCase().contains(kataKunci) ||
          a.kategori.toLowerCase().contains(kataKunci) ||
          a.lokasi.toLowerCase().contains(kataKunci);

      return cocokStatus && cocokPencarian;
    }).toList();
  }

  Color _warnaStatus(String status) {
    switch (status) {
      case 'Selesai':
        return const Color(0xFF2E7D32);
      case 'Proses':
        return const Color(0xFFEF6C00);
      default:
        return const Color(0xFFC62828);
    }
  }

  // ============================================================
  // DIALOG TANGANI ASPIRASI
  // ============================================================

  void _bukaDialogTangani(Aspirasi item) {
    String statusTerpilih = item.status == 'Menunggu' ? 'Proses' : item.status;
    final feedbackController = TextEditingController(text: item.feedback);

    Uint8List? fotoSelesaiBytes;
    String? fotoSelesaiBase64Baru;
    final ImagePicker picker = ImagePicker();

    if (item.fotoSelesaiBase64.isNotEmpty) {
      fotoSelesaiBytes = base64Decode(item.fotoSelesaiBase64);
    }

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            Future<void> pilihFotoSelesai() async {
              final XFile? file = await picker.pickImage(
                source: ImageSource.camera,
                imageQuality: 40,
                maxWidth: 800,
              );
              if (file == null) return;
              final bytes = await file.readAsBytes();
              setDialogState(() {
                fotoSelesaiBytes = bytes;
                fotoSelesaiBase64Baru = base64Encode(bytes);
              });
            }

            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.build_circle, color: AppColors.primary),
                          SizedBox(width: 8),
                          Text('Tangani Aspirasi',
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _baris('Pelapor', '${item.nama} (${item.kelas})'),
                      _baris('Kategori', item.kategori),
                      _baris('Lokasi', item.lokasi),
                      _baris('Keterangan', item.keterangan),
                      if (item.fotoBase64.isNotEmpty) ...[
                        const SizedBox(height: 12),
                        const Text('Foto Laporan (Sebelum):',
                            style: TextStyle(
                                fontWeight: FontWeight.w600, fontSize: 13)),
                        const SizedBox(height: 6),
                        GestureDetector(
                          onTap: () {
                            bukaFotoFullscreen(
                              context,
                              bytes: base64Decode(item.fotoBase64),
                              title: 'Foto Laporan Sebelum',
                            );
                          },
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.memory(
                              base64Decode(item.fotoBase64),
                              height: 160,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 18),
                      DropdownButtonFormField<String>(
                        value: statusTerpilih,
                        decoration: const InputDecoration(
                          labelText: 'Status Penanganan',
                        ),
                        items: const [
                          DropdownMenuItem(
                              value: 'Menunggu', child: Text('Menunggu')),
                          DropdownMenuItem(
                              value: 'Proses', child: Text('Proses')),
                          DropdownMenuItem(
                              value: 'Selesai', child: Text('Selesai')),
                        ],
                        onChanged: (value) {
                          if (value == null) return;
                          setDialogState(() => statusTerpilih = value);
                        },
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: feedbackController,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: 'Catatan Penanganan untuk Siswa',
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text('Foto Bukti Perbaikan (Sesudah):',
                          style: TextStyle(
                              fontWeight: FontWeight.w600, fontSize: 13)),
                      const SizedBox(height: 8),
                      if (fotoSelesaiBytes == null)
                        OutlinedButton.icon(
                          icon: const Icon(Icons.add_a_photo, size: 18),
                          label: const Text('Ambil / Upload Foto Selesai'),
                          onPressed: pilihFotoSelesai,
                        )
                      else
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GestureDetector(
                              onTap: () {
                                bukaFotoFullscreen(
                                  context,
                                  bytes: fotoSelesaiBytes!,
                                  title: 'Foto Bukti Perbaikan',
                                );
                              },
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.memory(
                                  fotoSelesaiBytes!,
                                  height: 160,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            TextButton.icon(
                              icon: const Icon(Icons.refresh, size: 16),
                              label: const Text('Ganti Foto'),
                              onPressed: pilihFotoSelesai,
                            ),
                          ],
                        ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('Batal'),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: () async {
                              await _service.updateStatusFeedback(
                                idAspirasi: item.id!,
                                status: statusTerpilih,
                                feedback: feedbackController.text.trim(),
                                fotoSelesaiBase64: fotoSelesaiBase64Baru,
                              );
                              SystemSound.play(SystemSoundType.click);
                              if (context.mounted) {
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content:
                                        Text('Status berhasil diperbarui!'),
                                    backgroundColor: AppColors.primary,
                                  ),
                                );
                              }
                            },
                            child: const Text('Simpan'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _baris(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black87, fontSize: 13),
          children: [
            TextSpan(
                text: '$label: ',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }

  void _logout() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LandingScreen()),
      (route) => false,
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(
            'Halo, ${widget.petugas.nama.isNotEmpty ? widget.petugas.nama : widget.petugas.username}'),
        actions: [
          StreamBuilder<int>(
            stream: NotificationService().streamJumlahBelumDibacaPetugas(),
            builder: (context, snapshot) {
              final jumlah = snapshot.data ?? 0;
              return Stack(
                alignment: Alignment.center,
                children: [
                  IconButton(
                    tooltip: 'Notifikasi',
                    icon: const Icon(Icons.notifications_none),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              const NotificationScreen(penerima: 'petugas'),
                        ),
                      );
                    },
                  ),
                  if (jumlah > 0)
                    Positioned(
                      right: 7,
                      top: 7,
                      child: Container(
                        constraints:
                            const BoxConstraints(minWidth: 18, minHeight: 18),
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: const BoxDecoration(
                          color: AppColors.red,
                          shape: BoxShape.circle,
                        ),
                        child: Text(
                          jumlah > 99 ? '99+' : '$jumlah',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.help_outline),
            tooltip: 'Bantuan',
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const HelpScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: _logout,
          ),
        ],
      ),
      body: StreamBuilder<List<Aspirasi>>(
        stream: _service.streamSemuaAspirasi(),
        builder: (context, snapshot) {
          final semua = snapshot.data ?? [];
          final daftar = _terapkanFilter(semua);

          final menunggu = semua.where((a) => a.status == 'Menunggu').length;
          final proses = semua.where((a) => a.status == 'Proses').length;
          final selesai = semua.where((a) => a.status == 'Selesai').length;

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(
                  children: [
                    _MiniStat(
                        label: 'Menunggu',
                        value: menunggu,
                        color: const Color(0xFFC62828)),
                    const SizedBox(width: 10),
                    _MiniStat(
                        label: 'Proses',
                        value: proses,
                        color: const Color(0xFFEF6C00)),
                    const SizedBox(width: 10),
                    _MiniStat(
                        label: 'Selesai',
                        value: selesai,
                        color: const Color(0xFF2E7D32)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                    labelText: 'Cari nama / kategori / lokasi',
                    prefixIcon: Icon(Icons.search),
                    isDense: true,
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SizedBox(
                  width: double.infinity,
                  child: Wrap(
                    spacing: 8,
                    children:
                        ['Aktif', 'Menunggu', 'Proses', 'Selesai', 'Semua']
                            .map((s) => ChoiceChip(
                                  label: Text(s),
                                  selected: _filterStatus == s,
                                  onSelected: (_) =>
                                      setState(() => _filterStatus = s),
                                ))
                            .toList(),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: snapshot.connectionState == ConnectionState.waiting
                    ? const Center(child: CircularProgressIndicator())
                    : daftar.isEmpty
                        ? const Center(child: Text('Tidak ada aspirasi.'))
                        : ListView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                            itemCount: daftar.length,
                            itemBuilder: (context, index) {
                              final item = daftar[index];
                              return _AspirasiCard(
                                item: item,
                                warnaStatus: _warnaStatus(item.status),
                                onTap: () => _bukaDialogTangani(item),
                              );
                            },
                          ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ============================================================
// MINI STAT
// ============================================================

class _MiniStat extends StatelessWidget {
  final String label;
  final int value;
  final Color color;

  const _MiniStat(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border(left: BorderSide(color: color, width: 4)),
        ),
        child: Column(
          children: [
            Text('$value',
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold, color: color)),
            Text(label,
                style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// KARTU ASPIRASI
// ============================================================

class _AspirasiCard extends StatelessWidget {
  final Aspirasi item;
  final Color warnaStatus;
  final VoidCallback onTap;

  const _AspirasiCard(
      {required this.item, required this.warnaStatus, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: item.fotoBase64.isNotEmpty
                    ? GestureDetector(
                        onTap: () {
                          bukaFotoFullscreen(
                            context,
                            bytes: base64Decode(item.fotoBase64),
                            title: 'Foto Pengaduan',
                          );
                        },
                        child: Image.memory(
                          base64Decode(item.fotoBase64),
                          width: 56,
                          height: 56,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Container(
                        width: 56,
                        height: 56,
                        color: AppColors.background,
                        child: const Icon(
                          Icons.image_not_supported,
                          color: Colors.grey,
                        ),
                      ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(item.kategori,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 14)),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: warnaStatus.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(item.status,
                              style: TextStyle(
                                  color: warnaStatus,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 11)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text('${item.nama} • ${item.kelas}',
                        style: TextStyle(
                            fontSize: 12, color: Colors.grey.shade600)),
                    const SizedBox(height: 2),
                    Text(item.lokasi,
                        style: TextStyle(
                            fontSize: 12, color: Colors.grey.shade600)),
                    Text(item.keterangan,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12.5)),
                    if (item.tanggal != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        DateFormat('dd MMM yyyy, HH:mm').format(item.tanggal!),
                        style: TextStyle(
                            fontSize: 10.5, color: Colors.grey.shade500),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
