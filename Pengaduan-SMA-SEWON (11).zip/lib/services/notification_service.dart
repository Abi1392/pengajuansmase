import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../app_globals.dart';
import '../screens/notification_screen.dart';

class NotificationService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  Future<String?> ambilToken() async {
    return null;
  }

  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>?
      _siswaNotificationSubscription;

  // ============================================================
  // NOTIFICATION CHANNEL ANDROID
  // ============================================================

  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'pengaduan_high',
    'Notifikasi Pengaduan',
    description: 'Notifikasi status pengaduan siswa',
    importance: Importance.max,
    playSound: true,
  );

  // ============================================================
  // INIT LOCAL NOTIFICATION
  // ============================================================

  Future<void> initLocalNotification() async {
    const androidSettings = AndroidInitializationSettings(
      '@mipmap/ic_launcher',
    );

    const settings = InitializationSettings(
      android: androidSettings,
    );

    await _localNotifications.initialize(
      settings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        final payload = response.payload;

        String? nis;

        if (payload != null && payload.trim().isNotEmpty) {
          nis = payload.trim();
        }

        navigatorKey.currentState?.push(
          MaterialPageRoute(
            builder: (_) => NotificationScreen(
              penerima: 'siswa',
              nis: nis,
            ),
          ),
        );
      },
    );

    final android = _localNotifications.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    await android?.createNotificationChannel(
      _channel,
    );

    await android?.requestNotificationsPermission();
  }

  // ============================================================
  // TAMPILKAN NOTIFIKASI LOKAL
  // ============================================================

  Future<void> tampilkanNotifikasi({
    required String judul,
    required String pesan,
    String? nis,
  }) async {
    final id = DateTime.now().millisecondsSinceEpoch;

    await _localNotifications.show(
      id ~/ 1000,
      judul,
      pesan,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'pengaduan_high',
          'Notifikasi Pengaduan',
          channelDescription: 'Notifikasi status pengaduan siswa',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          autoCancel: true,
        ),
      ),
      payload: nis,
    );
  }

  // ============================================================
  // MULAI MEMANTAU NOTIFIKASI SISWA
  // ============================================================

  Future<void> mulaiPantauNotifikasiSiswa(
    String nis,
  ) async {
    // Hentikan listener lama
    _siswaNotificationSubscription?.cancel();

    bool snapshotPertama = true;

    _siswaNotificationSubscription = _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'siswa',
        )
        .where(
          'nis',
          isEqualTo: nis,
        )
        .snapshots()
        .listen(
      (snapshot) async {
        // Snapshot pertama berisi notifikasi lama.
        // Jangan munculkan sebagai notifikasi baru.
        if (snapshotPertama) {
          snapshotPertama = false;
          return;
        }

        for (final change in snapshot.docChanges) {
          if (change.type != DocumentChangeType.added) {
            continue;
          }

          final data = change.doc.data();

          if (data == null) {
            continue;
          }

          final judul = data['judul']?.toString() ?? 'Notifikasi Baru';

          final pesan = data['pesan']?.toString() ?? 'Ada informasi baru.';

          final nisData = data['nis']?.toString() ?? nis;

          await tampilkanNotifikasi(
            judul: judul,
            pesan: pesan,
            nis: nisData,
          );
        }
      },
      onError: (error) {
        debugPrint(
          'Gagal memantau notifikasi siswa: '
          '$error',
        );
      },
    );
  }

  // ============================================================
  // HENTIKAN PEMANTAUAN
  // ============================================================

  Future<void> hentikanPantauanNotifikasi() async {
    await _siswaNotificationSubscription?.cancel();

    _siswaNotificationSubscription = null;
  }

  // ============================================================
  // BUAT NOTIFIKASI FIRESTORE
  // ============================================================

  Future<void> buatNotifikasi({
    required String penerima,
    required String judul,
    required String pesan,
    String? nis,
    String? idAspirasi,
  }) async {
    await _firestore.collection('notifications').add({
      'penerima': penerima,
      'nis': nis ?? '',
      'judul': judul,
      'pesan': pesan,
      'idAspirasi': idAspirasi ?? '',
      'dibaca': false,
      'waktu': FieldValue.serverTimestamp(),
    });
  }

  // ============================================================
  // NOTIFIKASI SISWA
  // ============================================================

  Future<void> notifikasiSiswa({
    required String nis,
    required String judul,
    required String pesan,
    String? idAspirasi,
  }) async {
    await buatNotifikasi(
      penerima: 'siswa',
      nis: nis,
      judul: judul,
      pesan: pesan,
      idAspirasi: idAspirasi,
    );
  }

  // ============================================================
  // NOTIFIKASI ADMIN
  // ============================================================

  Future<void> notifikasiAdmin({
    required String judul,
    required String pesan,
    String? idAspirasi,
  }) async {
    await buatNotifikasi(
      penerima: 'admin',
      judul: judul,
      pesan: pesan,
      idAspirasi: idAspirasi,
    );
  }

  // ============================================================
  // NOTIFIKASI PETUGAS
  // ============================================================

  Future<void> notifikasiPetugas({
    required String judul,
    required String pesan,
    String? idAspirasi,
  }) async {
    await buatNotifikasi(
      penerima: 'petugas',
      judul: judul,
      pesan: pesan,
      idAspirasi: idAspirasi,
    );
  }

  // ============================================================
  // STREAM NOTIFIKASI SISWA
  // ============================================================

  Stream<QuerySnapshot<Map<String, dynamic>>> streamNotifikasiSiswa(
    String nis,
  ) {
    return _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'siswa',
        )
        .where(
          'nis',
          isEqualTo: nis,
        )
        .orderBy(
          'waktu',
          descending: true,
        )
        .snapshots();
  }

  // ============================================================
  // STREAM NOTIFIKASI ADMIN
  // ============================================================

  Stream<QuerySnapshot<Map<String, dynamic>>> streamNotifikasiAdmin() {
    return _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'admin',
        )
        .orderBy(
          'waktu',
          descending: true,
        )
        .snapshots();
  }

  // ============================================================
  // STREAM NOTIFIKASI PETUGAS
  // ============================================================

  Stream<QuerySnapshot<Map<String, dynamic>>> streamNotifikasiPetugas() {
    return _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'petugas',
        )
        .orderBy(
          'waktu',
          descending: true,
        )
        .snapshots();
  }

  // ============================================================
  // BELUM DIBACA SISWA
  // ============================================================

  Stream<int> streamJumlahBelumDibacaSiswa(
    String nis,
  ) {
    return _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'siswa',
        )
        .where(
          'nis',
          isEqualTo: nis,
        )
        .where(
          'dibaca',
          isEqualTo: false,
        )
        .snapshots()
        .map(
          (snapshot) => snapshot.docs.length,
        );
  }

  // ============================================================
  // BELUM DIBACA ADMIN
  // ============================================================

  Stream<int> streamJumlahBelumDibacaAdmin() {
    return _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'admin',
        )
        .where(
          'dibaca',
          isEqualTo: false,
        )
        .snapshots()
        .map(
          (snapshot) => snapshot.docs.length,
        );
  }

  // ============================================================
  // BELUM DIBACA PETUGAS
  // ============================================================

  Stream<int> streamJumlahBelumDibacaPetugas() {
    return _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'petugas',
        )
        .where(
          'dibaca',
          isEqualTo: false,
        )
        .snapshots()
        .map(
          (snapshot) => snapshot.docs.length,
        );
  }

  // ============================================================
  // TANDAI SEMUA SISWA
  // ============================================================

  Future<void> tandaiSemuaDibacaSiswa(
    String nis,
  ) async {
    final snapshot = await _firestore
        .collection('notifications')
        .where(
          'penerima',
          isEqualTo: 'siswa',
        )
        .where(
          'nis',
          isEqualTo: nis,
        )
        .where(
          'dibaca',
          isEqualTo: false,
        )
        .get();

    if (snapshot.docs.isEmpty) {
      return;
    }

    final batch = _firestore.batch();

    for (final doc in snapshot.docs) {
      batch.update(
        doc.reference,
        {
          'dibaca': true,
        },
      );
    }

    await batch.commit();
  }

  // ============================================================
  // TANDAI SATU NOTIFIKASI
  // ============================================================

  Future<void> tandaiDibaca(
    String notificationId,
  ) async {
    await _firestore.collection('notifications').doc(notificationId).update({
      'dibaca': true,
    });
  }
}
