import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/aspirasi.dart';
import '../models/siswa.dart';
import '../models/admin.dart';
import '../models/petugas.dart';
import 'notification_service.dart';

class FirestoreService {
  final CollectionReference<Map<String, dynamic>> _aspirasiRef =
      FirebaseFirestore.instance.collection(
    'aspirasi',
  );

  final CollectionReference<Map<String, dynamic>> _siswaRef =
      FirebaseFirestore.instance.collection(
    'siswa',
  );

  final CollectionReference<Map<String, dynamic>> _adminRef =
      FirebaseFirestore.instance.collection(
    'admin',
  );

  final CollectionReference<Map<String, dynamic>> _petugasRef =
      FirebaseFirestore.instance.collection(
    'petugas',
  );

  final NotificationService _notificationService = NotificationService();

  // ============================================================
  // TAMBAH ASPIRASI
  // ============================================================

  Future<void> tambahAspirasi(
    Aspirasi aspirasi,
  ) async {
    // Simpan pengaduan terlebih dahulu
    final docRef = await _aspirasiRef.add(
      aspirasi.toMap(),
    );

    // ==========================================================
    // NOTIFIKASI ADMIN
    // ==========================================================

    await _notificationService.notifikasiAdmin(
      judul: 'Pengaduan Baru',
      pesan: 'Ada pengaduan baru dari siswa ${aspirasi.nama}. '
          'Kategori: ${aspirasi.kategori}. '
          'Lokasi: ${aspirasi.lokasi}.',
      idAspirasi: docRef.id,
    );

    // ==========================================================
    // NOTIFIKASI PETUGAS
    // ==========================================================

    await _notificationService.notifikasiPetugas(
      judul: 'Tugas Pengaduan Baru',
      pesan: 'Ada pengaduan sarana baru yang perlu ditangani. '
          'Kategori: ${aspirasi.kategori}. '
          'Lokasi: ${aspirasi.lokasi}.',
      idAspirasi: docRef.id,
    );
  }

  // ============================================================
  // STREAM HISTORI SISWA
  // ============================================================

  Stream<List<Aspirasi>> streamHistoriByNis(
    String nis,
  ) {
    return _aspirasiRef
        .where(
          'nis',
          isEqualTo: nis,
        )
        .orderBy(
          'tanggal',
          descending: true,
        )
        .snapshots()
        .map(
          (snap) => snap.docs
              .map(
                (d) => Aspirasi.fromDoc(d),
              )
              .toList(),
        );
  }

  // ============================================================
  // CARI SISWA
  // ============================================================

  Future<Siswa?> cariSiswaByNis(
    String nis,
  ) async {
    final doc = await _siswaRef.doc(nis).get();

    if (!doc.exists) {
      return null;
    }

    return Siswa.fromMap(
      doc.data()!,
    );
  }

  // ============================================================
  // DAFTAR SISWA
  // ============================================================

  Future<void> daftarSiswaBaru(
    Siswa siswa,
  ) async {
    await _siswaRef.doc(siswa.nis).set(
          siswa.toMap(),
        );
  }

  // ============================================================
  // STREAM SEMUA ASPIRASI
  // ============================================================

  Stream<List<Aspirasi>> streamSemuaAspirasi() {
    return _aspirasiRef
        .orderBy(
          'tanggal',
          descending: true,
        )
        .snapshots()
        .map(
          (snap) => snap.docs
              .map(
                (d) => Aspirasi.fromDoc(d),
              )
              .toList(),
        );
  }

  // ============================================================
  // UPDATE STATUS + FEEDBACK
  // ============================================================

  Future<void> updateStatusFeedback({
    required String idAspirasi,
    required String status,
    required String feedback,
    String? fotoSelesaiBase64,
  }) async {
    // ==========================================================
    // AMBIL DATA ASPIRASI LAMA
    // ==========================================================

    final doc = await _aspirasiRef.doc(idAspirasi).get();

    if (!doc.exists) {
      throw Exception(
        'Data pengaduan tidak ditemukan.',
      );
    }

    final aspirasi = Aspirasi.fromDoc(doc);

    // ==========================================================
    // DATA YANG AKAN DIUPDATE
    // ==========================================================

    final data = <String, dynamic>{
      'status': status,
      'feedback': feedback,
    };

    if (fotoSelesaiBase64 != null) {
      data['foto_selesai_base64'] = fotoSelesaiBase64;
    }

    // ==========================================================
    // UPDATE FIREBASE
    // ==========================================================

    await _aspirasiRef.doc(idAspirasi).update(data);

    // ==========================================================
    // CEK APAKAH STATUS BERUBAH
    // ==========================================================

    final statusBerubah = aspirasi.status != status;

    final feedbackBerubah = aspirasi.feedback != feedback;

    // ==========================================================
    // JIKA TIDAK ADA PERUBAHAN
    // ==========================================================

    if (!statusBerubah && !feedbackBerubah) {
      return;
    }

    // ==========================================================
    // BUAT PESAN UNTUK SISWA
    // ==========================================================

    String judul;
    String pesan;

    if (status == 'Selesai') {
      judul = 'Pengaduan Selesai';

      pesan = 'Pengaduan kamu di ${aspirasi.lokasi} '
          'telah diselesaikan.';
    } else if (status == 'Proses') {
      judul = 'Pengaduan Diproses';

      pesan = 'Pengaduan kamu di ${aspirasi.lokasi} '
          'sedang diproses oleh petugas.';
    } else {
      judul = 'Status Pengaduan Diperbarui';

      pesan = 'Status pengaduan kamu di ${aspirasi.lokasi} '
          'sekarang: $status.';
    }

    // ==========================================================
    // TAMBAHKAN FEEDBACK JIKA ADA
    // ==========================================================

    if (feedback.isNotEmpty && feedbackBerubah) {
      pesan += '\n\nFeedback admin: $feedback';
    }

    // ==========================================================
    // NOTIFIKASI SISWA
    // ==========================================================

    await _notificationService.notifikasiSiswa(
      nis: aspirasi.nis,
      judul: judul,
      pesan: pesan,
      idAspirasi: idAspirasi,
    );
  }

  // ============================================================
  // RATING PENGADUAN OLEH SISWA
  // ============================================================

  Future<void> beriRating({
    required String idAspirasi,
    required int rating,
  }) async {
    if (rating < 1 || rating > 5) {
      throw Exception(
        'Rating harus antara 1 sampai 5.',
      );
    }

    final ref = _aspirasiRef.doc(idAspirasi);

    await FirebaseFirestore.instance.runTransaction(
      (transaction) async {
        final snapshot = await transaction.get(ref);

        if (!snapshot.exists) {
          throw Exception(
            'Data pengaduan tidak ditemukan.',
          );
        }

        final data = snapshot.data();

        final ratingLama = data?['rating'];

        // Mencegah siswa memberi rating kedua kali
        if (ratingLama != null) {
          throw Exception(
            'Pengaduan ini sudah diberi rating.',
          );
        }

        final status = data?['status']?.toString() ?? '';

        if (status != 'Selesai') {
          throw Exception(
            'Rating hanya dapat diberikan '
            'setelah pengaduan selesai.',
          );
        }

        transaction.update(
          ref,
          {
            'rating': rating,
          },
        );
      },
    );
  }
  // ============================================================
  // LOGIN ADMIN
  // ============================================================

  Future<bool> verifikasiAdmin(
    String username,
    String password,
  ) async {
    final snap = await _adminRef
        .where(
          'username',
          isEqualTo: username,
        )
        .limit(1)
        .get();

    if (snap.docs.isEmpty) {
      return false;
    }

    final admin = Admin.fromMap(
      snap.docs.first.data(),
    );

    if (admin.password != password) {
      return false;
    }

    // ==========================================================
    // SIMPAN TOKEN FCM ADMIN
    // ==========================================================

    final token = await _notificationService.ambilToken();

    if (token != null) {
      await snap.docs.first.reference.update({
        'fcmToken': token,
      });
    }

    return true;
  }

  // ============================================================
  // LOGIN PETUGAS
  // ============================================================

  Future<Petugas?> loginPetugas(
    String username,
    String password,
  ) async {
    final snap = await _petugasRef
        .where(
          'username',
          isEqualTo: username,
        )
        .limit(1)
        .get();

    if (snap.docs.isEmpty) {
      return null;
    }

    final petugas = Petugas.fromMap(
      snap.docs.first.data(),
    );

    if (petugas.password != password) {
      return null;
    }

    // ==========================================================
    // SIMPAN TOKEN FCM PETUGAS
    // ==========================================================

    final token = await _notificationService.ambilToken();

    if (token != null) {
      await snap.docs.first.reference.update({
        'fcmToken': token,
      });
    }

    return petugas;
  }
}
