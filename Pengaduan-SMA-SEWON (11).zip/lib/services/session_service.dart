import 'package:shared_preferences/shared_preferences.dart';

import '../models/siswa.dart';

class SessionService {
  static const String _loginKey = 'siswa_login';
  static const String _nisKey = 'siswa_nis';
  static const String _namaKey = 'siswa_nama';
  static const String _kelasKey = 'siswa_kelas';

  // ============================================================
  // SIMPAN SESI SISWA
  // ============================================================

  Future<void> simpanSesi(Siswa siswa) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(_loginKey, true);
    await prefs.setString(_nisKey, siswa.nis);
    await prefs.setString(_namaKey, siswa.nama);
    await prefs.setString(_kelasKey, siswa.kelas);
  }

  // ============================================================
  // AMBIL SESI SISWA
  // ============================================================

  Future<Siswa?> ambilSesi() async {
    final prefs = await SharedPreferences.getInstance();

    final sudahLogin = prefs.getBool(_loginKey) ?? false;

    if (!sudahLogin) {
      return null;
    }

    final nis = prefs.getString(_nisKey);
    final nama = prefs.getString(_namaKey);
    final kelas = prefs.getString(_kelasKey);

    if (nis == null ||
        nama == null ||
        kelas == null ||
        nis.isEmpty ||
        nama.isEmpty ||
        kelas.isEmpty) {
      await hapusSesi();
      return null;
    }

    return Siswa(
      nis: nis,
      nama: nama,
      kelas: kelas,
      password: '',
    );
  }

  // ============================================================
  // CEK LOGIN
  // ============================================================

  Future<bool> sudahLogin() async {
    final prefs = await SharedPreferences.getInstance();

    return prefs.getBool(_loginKey) ?? false;
  }

  // ============================================================
  // HAPUS SESI / LOGOUT
  // ============================================================

  Future<void> hapusSesi() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.remove(_loginKey);
    await prefs.remove(_nisKey);
    await prefs.remove(_namaKey);
    await prefs.remove(_kelasKey);
  }
}
