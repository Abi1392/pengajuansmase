const { onDocumentCreated } =
  require("firebase-functions/v2/firestore");

const admin = require("firebase-admin");

admin.initializeApp();

const db = admin.firestore();

/**
 * ============================================================
 * KETIKA DOKUMEN NOTIFICATIONS DIBUAT
 * ============================================================
 *
 * Flutter:
 *
 * notifications/{id}
 *
 *        ↓
 *
 * Cloud Function
 *
 *        ↓
 *
 * cari fcmToken siswa
 *
 *        ↓
 *
 * Firebase Cloud Messaging
 *
 *        ↓
 *
 * HP siswa
 */
exports.kirimNotifikasi = onDocumentCreated(
  "notifications/{notificationId}",
  async (event) => {
    const snapshot = event.data;

    if (!snapshot) {
      console.log(
        "Data notification kosong."
      );

      return;
    }

    const data = snapshot.data();

    const penerima =
      data.penerima || "";

    const nis =
      data.nis || "";

    const judul =
      data.judul ||
      "Notifikasi Baru";

    const pesan =
      data.pesan ||
      "Ada informasi baru.";

    const idAspirasi =
      data.idAspirasi || "";

    console.log(
      "Notification baru:",
      {
        penerima,
        nis,
        judul,
        idAspirasi,
      }
    );

    // ==========================================================
    // HANYA KIRIM PUSH UNTUK SISWA
    // ==========================================================

    if (
      penerima !== "siswa" ||
      !nis
    ) {
      console.log(
        "Bukan notifikasi siswa. Tidak mengirim FCM."
      );

      return;
    }

    // ==========================================================
    // CARI DATA SISWA
    // ==========================================================

    const siswaRef =
      db.collection("siswa")
        .doc(String(nis));

    const siswaSnap =
      await siswaRef.get();

    if (!siswaSnap.exists) {
      console.log(
        "Siswa tidak ditemukan:",
        nis
      );

      return;
    }

    const siswa =
      siswaSnap.data();

    const token =
      siswa.fcmToken;

    if (
      !token ||
      typeof token !== "string"
    ) {
      console.log(
        "Siswa belum memiliki FCM token:",
        nis
      );

      return;
    }

    // ==========================================================
    // DATA YANG DIKIRIM KE HP
    // ==========================================================

    const message = {
      token: token,

      notification: {
        title: String(judul),
        body: String(pesan),
      },

      data: {
        penerima: "siswa",
        nis: String(nis),
        judul: String(judul),
        pesan: String(pesan),
        idAspirasi: String(idAspirasi),
      },

      android: {
        priority: "high",

        notification: {
          channelId:
            "pengaduan_channel",

          sound:
            "default",

          priority:
            "high",

          defaultVibrateTimings:
            true,
        },
      },
    };

    // ==========================================================
    // KIRIM FCM
    // ==========================================================

    try {
      const response =
        await admin
          .messaging()
          .send(message);

      console.log(
        "NOTIFIKASI BERHASIL DIKIRIM:",
        response
      );
    } catch (error) {
      console.error(
        "GAGAL MENGIRIM NOTIFIKASI:",
        error
      );

      // ========================================================
      // TOKEN SUDAH TIDAK VALID
      // ========================================================

      if (
        error.code ===
          "messaging/registration-token-not-registered" ||
        error.code ===
          "messaging/invalid-registration-token"
      ) {
        await siswaRef.update({
          fcmToken:
            admin.firestore.FieldValue.delete(),
        });

        console.log(
          "FCM token lama dihapus:",
          nis
        );
      }
    }
  }
);